const listaCPFs = ["12365242625","9242624265","9352524652"]

// const cliente = ["nome","André","idade",36]

const cliente = {
    nome:"Andre",
    idade:36,
    cpf:"12543652266",
    email:"andre@email.com"
}