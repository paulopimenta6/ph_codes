//Aluno: Paulo Henrique de Almeida Soares Pimenta

package com.utfpr.backendempresa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendEmpresaApplicationTests {

	@Test
	void contextLoads() {
	}

}
