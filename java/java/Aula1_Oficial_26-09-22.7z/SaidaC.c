int main(){
	
	printf("\n Saida de Dados em C \n\n");
	
}
