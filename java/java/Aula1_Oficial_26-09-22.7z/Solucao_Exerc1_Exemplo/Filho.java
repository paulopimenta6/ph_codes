public class Filho{

	private int idade;
	private String apelido;


	public int getIdade(){
		return idade;
	}

	public String getApelido(){
		return apelido;
	}

	public void setIdade(int idade){
		this.idade = idade;
	}

	public void setApelido(String apelido){
		this.apelido = apelido;
	}

}