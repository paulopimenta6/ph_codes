public class SaidaJ{

	public static void main(String arg[]){
		System.out.println("\n\n Saida de Dados em Java\n\n");
	}

}